module github.com/trzsz/tsshd

go 1.25.0

require (
	github.com/Microsoft/go-winio v0.6.2
	github.com/UserExistsError/conpty v0.1.4
	github.com/creack/pty v1.1.24
	github.com/google/shlex v0.0.0-20191202100458-e7afc7fbc510
	github.com/quic-go/quic-go v0.59.0
	github.com/stretchr/testify v1.11.1
	github.com/trzsz/shellescape v1.6.0
	github.com/trzsz/smux v1.6.0
	github.com/xtaci/kcp-go/v5 v5.6.72
	golang.org/x/crypto v0.50.0
	golang.org/x/net v0.53.0
	golang.org/x/sys v0.43.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/klauspost/cpuid/v2 v2.3.0 // indirect
	github.com/klauspost/reedsolomon v1.14.0 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/tjfoc/gmsm v1.4.1 // indirect
	go.uber.org/mock v0.6.0 // indirect
	golang.org/x/time v0.15.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
