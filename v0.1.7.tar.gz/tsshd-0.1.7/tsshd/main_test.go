/*
MIT License

Copyright (c) 2024-2026 The Trzsz SSH Authors.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

package tsshd

import (
	"sync"
	"sync/atomic"
	"testing"
)

func TestAddOnExitFunc_Concurrent(t *testing.T) {
	onExitMutex.Lock()
	saved := append([]func(){}, onExitFuncs...)
	onExitFuncs = nil
	onExitMutex.Unlock()
	defer func() {
		onExitMutex.Lock()
		onExitFuncs = saved
		onExitMutex.Unlock()
	}()

	var executed atomic.Int32
	const total = 200
	var wg sync.WaitGroup
	wg.Add(total)
	for range total {
		go func() {
			defer wg.Done()
			addOnExitFunc(func() {
				executed.Add(1)
			})
		}()
	}
	wg.Wait()

	cleanupOnExit()

	if got := executed.Load(); got != total {
		t.Fatalf("cleanupOnExit executed %d handlers, want %d", got, total)
	}
	onExitMutex.Lock()
	defer onExitMutex.Unlock()
	if len(onExitFuncs) != 0 {
		t.Fatalf("cleanupOnExit should drain handlers, got %d remaining", len(onExitFuncs))
	}
}
